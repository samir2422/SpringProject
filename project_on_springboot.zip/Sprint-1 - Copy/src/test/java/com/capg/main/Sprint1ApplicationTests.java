package com.capg.main;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capg.main.pojo.customer;
import com.capg.main.pojo.food;
import com.capg.main.pojo.orders;
import com.capg.main.repository.FoodRepository;
import com.capg.main.repository.OrdersRepository;

@SpringBootTest
class Sprint1ApplicationTests {
	
	@Autowired
	private OrdersRepository prepo;
	@Autowired
	private FoodRepository repo;
	@Test
	void testsearchbyid()
	{
		Optional<orders> op = prepo.findById(10);
		orders o;
		if (op.isPresent()) {
			o = op.get();
			System.out.println("##10Marks##");
		}
		else
		{
			assertThat("F").isEqualTo("A");
		}
	}
	@Test
	void testSavefood()
	{
		food f=new food(1,"Pizza",149,1 );
		customer c=new customer(1,"Samir","samirimtiaz8@gmail.com");
		orders o=new orders(1,"20/10/2021",f,c);
		orders fod=prepo.save(o);
		assertThat(fod.getOid()).isEqualTo(1);
		System.out.println("##10Marks##");
	}
	
	@Test
	void testAllOrders()
	{
		List<orders> list=new ArrayList();
		prepo.findAll().forEach(list::add);
		assertThat(list.size()).isGreaterThanOrEqualTo(1);
		System.out.println("##10Marks##");
	}
	@Test
	void testFoodinRange (){
		int size=repo.SearchInRange(100, 200).size();
		assertThat(size).isGreaterThan(0);
		System.out.println("##10Marks##");
	}
	@Test
	void testFoodDeleteById()
	{
		prepo.deleteById(1);
		assertThat(prepo.count()).isEqualTo(0);
		System.out.println("##10Marks##");
	}
	@Test
	void testOrdersDelete()
	{
		prepo.deleteAll();
		assertThat(prepo.count()).isEqualTo(0);
		System.out.println("##10Marks##");
	}
	@Test
	void testFindByName()
	{
		food f=repo.SearchByName("");
		System.out.println(f);
		assertThat(f).isEqualTo(null);
	}
	@Test
	void testGetbydate()
	{
		List<orders> or=prepo.findAllByDate("21-10-2021");
		assertThat(or.size()).isGreaterThanOrEqualTo(1);
	}
	
}
