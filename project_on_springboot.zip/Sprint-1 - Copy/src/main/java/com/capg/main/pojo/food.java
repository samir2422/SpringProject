package com.capg.main.pojo;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
@Entity
public class food {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
@NotEmpty(message = "FoodName Should  Not Be Empty!")
private String fname;
@Min(value=9,message="Minimum price must be 9")
private int price;
@Min(value=1,message="Minimum quantity must be 1")
private int quantity;

public food() {
	super();
}

public food(int id, @NotEmpty(message = "FoodName Should  Not Be Empty!") String fname,
		@Min(value = 9, message = "Minimum price must be 9") int price,
		@Min(value = 1, message = "Minimum quantity must be 1") int quantity) {
	super();
	this.id = id;
	this.fname = fname;
	this.price = price;
	this.quantity = quantity;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}

@Override
public String toString() {
	return "food [id=" + id + ", fname=" + fname + ", price=" + price + ", quantity=" + quantity + "]";
}

}
