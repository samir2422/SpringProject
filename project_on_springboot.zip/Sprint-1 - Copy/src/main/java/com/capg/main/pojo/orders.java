package com.capg.main.pojo;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
@Entity
public class orders {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int oid;
	@NotEmpty(message = "Date Should  Not Be Empty!")
	private String odate;
	@OneToOne
	private food i;
	@OneToOne
	private customer c;
	
	public orders() {
		super();
	}
	public orders(int oid, String odate, food i, customer c) {
		super();
		this.oid = oid;
		this.odate = odate;
		this.i = i;
		this.c = c;
	}
	
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getOdate() {
		return odate;
	}
	public void setOdate(String odate) {
		this.odate = odate;
	}
	public food getI() {
		return i;
	}
	public void setI(food i) {
		this.i = i;
	}
	public customer getC() {
		return c;
	}
	public void setC(customer c) {
		this.c = c;
	}
	@Override
	public String toString() {
		return "order [oid=" + oid + ", odate=" + odate + ", i=" + i + ", c=" + c + "]";
	}
	
}
