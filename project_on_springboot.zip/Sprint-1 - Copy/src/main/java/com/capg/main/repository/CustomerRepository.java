package com.capg.main.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.main.pojo.customer;
@Repository
public interface CustomerRepository extends CrudRepository<customer,Integer> {
	@Query(value="select c from customer c where c.cname=:name")
	customer SearchByName(@Param("name") String name);
}
