package com.capg.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.main.pojo.customer;
import com.capg.main.pojo.food;
import com.capg.main.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository repo;
	public Optional<customer> saveCustomer(customer c) {
		repo.save(c);
		return repo.findById(c.getId());
	}
	public Optional<customer> Detail(int itemid) {
		return repo.findById(itemid);
	}
	
	public List<customer> AllCustomer(){
		List<customer> list = new ArrayList();
		repo.findAll().forEach(list::add);
		return list;
	}
	public void Delete(int itemid)
	{
		repo.deleteById(itemid);
	}
	public void DeleteAll()
	{
		repo.deleteAll();
	}
	public customer SearchByName(String name)
	{
		customer c= repo.SearchByName(name);
		if(c==null)
			return null;
		return c;
	}
}
