package com.capg.main.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
@Entity
public class customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotEmpty(message = "UserName Should  Not Be Empty!")
	private String cname;
	@Email(message = "Email Should be Properly")
	private String email;
	public customer()
	{
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public customer(int id, @NotEmpty(message = "UserName Should  Not Be Empty!") String cname,
			@Email(message = "Email Should be Properly") String email) {
		super();
		this.id = id;
		this.cname = cname;
		this.email = email;
	}
	@Override
	public String toString() {
		return "customer [id=" + id + ", cname=" + cname + ", email=" + email + "]";
	}
	
}