package com.capg.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.main.pojo.customer;
import com.capg.main.pojo.food;
import com.capg.main.pojo.orders;



@Repository
public interface FoodRepository extends CrudRepository<food,Integer> {
	@Query(value="select f from food f where f.fname=:name")
	food SearchByName(@Param("name") String name);
	@Query(value="select f from food f where f.price between :low and :high")
	List<food> SearchInRange(@Param("low") int low,@Param("high") int high);
	@Query(value="select f from food f order by f.price ")
	List<food> SortByPrice();
	
}

