package com.capg.main.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.main.pojo.customer;
import com.capg.main.pojo.food;
import com.capg.main.pojo.orders;
import com.capg.main.service.CustomerService;
import com.capg.main.service.FoodService;
import com.capg.main.service.OrdersService;

@RestController
@RequestMapping("/orders/")
public class OrdersController {
	@Autowired
	OrdersService oservice;
	@Autowired
	FoodService fservice;
	@Autowired
	CustomerService cservice;

	@GetMapping("getOrder/{itemid}")
	public ResponseEntity<Object> getOrderDetails(@PathVariable("itemid") int itemid) {
		Optional<orders> op = oservice.Detail(itemid);
		if (op.isPresent()) {
			orders o = op.get();
			return new ResponseEntity<Object>(o, HttpStatus.OK);
		} else {
			return new ResponseEntity<Object>("Item is not present", HttpStatus.NOT_FOUND);
		}

	}

	@PostMapping("/save")
	public ResponseEntity<String> saveOrder(@RequestBody @Valid orders o) {
		   
		food present=fservice.SearchByName(o.getI().getFname());
		if(present==null)
			fservice.saveFood(o.getI());
		else
			o.setI(present);
		customer cum=cservice.SearchByName(o.getC().getCname());
		if(cum==null)
			cservice.saveCustomer(o.getC());
		else
			o.setC(cum);
		 oservice.saveOrders(o);
		
	    return new ResponseEntity<String>("Successfully added", HttpStatus.CREATED);

	}

	@DeleteMapping("/deleteOrder/{id}")
	public ResponseEntity<String> deleteorderById(@PathVariable("id") int id) {
		Optional<orders> o=oservice.Detail(id);
		if(o.isPresent())
		{
			oservice.Delete(id);
			return new ResponseEntity<String>("DELETE-SUCCESSFULLY", HttpStatus.OK);
		}
		else
			return new ResponseEntity<String>("Item Not found",HttpStatus.EXPECTATION_FAILED);
	}
	

	@PutMapping("/updateOrder/{id}")
	public ResponseEntity<Object> updateOrderById(@PathVariable("id") int id, @RequestBody @Valid orders f) {
		Optional<orders> op = oservice.Detail(id);
		if (op.isPresent()) {
			orders o = op.get();
			o.setOdate(f.getOdate());
			o.getI().setFname(f.getI().getFname());
			o.getI().setPrice(f.getI().getPrice());
			o.getI().setQuantity(f.getI().getQuantity());
			o.getC().setCname(f.getC().getCname());
			o.getC().setEmail(f.getC().getEmail());
			oservice.saveOrders(o);
			
			return new ResponseEntity<Object>(op.get(), HttpStatus.OK);
		} else
			return new ResponseEntity<Object>("NOT FOUND", HttpStatus.NOT_FOUND);
	}

	@DeleteMapping("/deleteallorders")
	public ResponseEntity<String> DeleteAllOrders() {
		oservice.DeleteAll();
		return new ResponseEntity<String>("DELETED ALL Orders", HttpStatus.GONE);
	}
	@GetMapping("/allOrders")
	public List<orders> getAllOrders() {
		List<orders> list = oservice.AllOrders();
		return list;
	}
	@GetMapping("/getname/{name}")
	public ResponseEntity<Object> SearchByName(@PathVariable("name") String name)
	{
		food f= fservice.SearchByName(name);
		if(f==null)
			return new ResponseEntity<Object>("Name Not found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<Object>(f,HttpStatus.FOUND);
	}
	@GetMapping("/getinrange/{low}/{high}")
	public List<food> SearchInRange(@PathVariable("low") int low,@PathVariable("high") int high)
	{
		return fservice.SearchInRange(low, high);
	}
	@GetMapping("/sortbyprice")
	public List<food> SortByPrice()
	{
		return fservice.SortByPrice();
	}
	@GetMapping("/getbydate/{date}")
	public ResponseEntity<Object> FindAllDate(@PathVariable("date")String date)
	{
		List<orders> l= oservice.findAllByDate(date);
		if(l.size()>0)
			return new ResponseEntity<Object>(l,HttpStatus.FOUND);
		return new ResponseEntity<Object>("Not Found",HttpStatus.NOT_FOUND);
	}
}
