package com.capg.main.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import com.capg.main.pojo.customer;
import com.capg.main.pojo.food;
import com.capg.main.pojo.orders;
import com.capg.main.repository.FoodRepository;
import com.capg.main.service.FoodService;

@RestController
@RequestMapping("/food/")
public class FoodController {

	@Autowired
	FoodService fservice;
	@Autowired
	FoodRepository repo;
	
	//Retrive data from table
	@GetMapping("getProduct/{itemid}")
	public ResponseEntity<Object> getProductDetails(@PathVariable("itemid") int itemid) {
		Optional<food> op = fservice.Detail(itemid);
		if (op.isPresent()) {
			food fod = op.get();
			return new ResponseEntity<Object>(fod, HttpStatus.OK);
		} else {
			return new ResponseEntity<Object>("Item is not present", HttpStatus.NOT_FOUND);
		}

	}
	@PostMapping("/save")
	public ResponseEntity<String> saveFood(@RequestBody @Valid food fod) {
		
		food op = fservice.SearchByName(fod.getFname());
		if (!(op==null)) {
			return new ResponseEntity<String>("Food Item already present", HttpStatus.ALREADY_REPORTED);
		}
		fservice.saveFood(fod);
		return new ResponseEntity<String>("Successfully added", HttpStatus.CREATED);

	}
	@DeleteMapping("/deletefood/{id}")
	public ResponseEntity<String> deleteProductById(@PathVariable("id") int id)
	{
		Optional<food> op=fservice.Detail(id);
		if(op.isPresent())
		{
			fservice.Delete(id);
			return new ResponseEntity<String>("DELETE-SUCCESSFULLY",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Not Found",HttpStatus.NOT_FOUND);
	}
	@PutMapping("/updatefood/{id}")
	public ResponseEntity<Object> updateProductById(@PathVariable("id") int id, @RequestBody @Valid food f)
	{
		Optional<food> op= fservice.Detail(id);
		if(op.isPresent())
		{
			food i=op.get();
			i.setFname(f.getFname());
			i.setPrice(f.getPrice());
			i.setQuantity(f.getQuantity());
			Optional<food> fo=fservice.saveFood(i);
			return new ResponseEntity<Object>(fo.get(),HttpStatus.OK);
			
		}
		else
			return new ResponseEntity<Object>("NOT FOUND",HttpStatus.NOT_FOUND);
	}
	@DeleteMapping("/deleteallfood")
	public ResponseEntity<String> DeleteAllFoods()
	{
		fservice.DeleteAll();
		return new ResponseEntity<String>("DELETED ALL FOOD",HttpStatus.GONE);
	}
	// Get all food item
		@GetMapping("/allFood")
		
		public List<food> getAllFood() {
			List<food> list = fservice.AllFood();
			return list;
		}
		@PostMapping("/save-food")
		public String SaveFood(@ModelAttribute("food") food f) {
			 repo.save(f);
			return "redirect:/food/foods";
		}
	
}