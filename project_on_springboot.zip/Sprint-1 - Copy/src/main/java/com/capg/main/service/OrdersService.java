package com.capg.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.main.pojo.orders;
import com.capg.main.repository.OrdersRepository;
@Service
public class OrdersService {
	@Autowired
	private OrdersRepository repo;

	public Optional<orders> saveOrders(orders o) {
		repo.save(o);
		return repo.findById(o.getOid());
	}
	
	public Optional<orders> Detail(int itemid) {
		return repo.findById(itemid);
	}
	
	public List<orders> AllOrders(){
		List<orders> list = new ArrayList();
		repo.findAll().forEach(list::add);
		return list;
	}
	public void Delete(int itemid)
	{
		repo.deleteById(itemid);
	}
	public void DeleteAll()
	{
		repo.deleteAll();
	}
	public List<orders> findAllByDate(String date)
	{
		List<orders> list= new ArrayList();
		repo.findAllByDate(date).forEach(list::add);
		return list;
	}
}
