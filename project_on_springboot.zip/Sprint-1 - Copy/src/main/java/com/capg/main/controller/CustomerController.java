package com.capg.main.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.main.pojo.customer;
import com.capg.main.pojo.food;
import com.capg.main.service.CustomerService;

@RestController
@RequestMapping("/customer/")
public class CustomerController {
@Autowired
CustomerService cservice;
@GetMapping("getCustomer/{itemid}")

public ResponseEntity<Object> getCustomerDetails(@PathVariable("itemid") int itemid) {
	Optional<customer> op = cservice.Detail(itemid);
	if (op.isPresent()) {
		customer c = op.get();
		return new ResponseEntity<Object>(c, HttpStatus.OK);
	} else {
		return new ResponseEntity<Object>("Item is not present", HttpStatus.NOT_FOUND);
	}

}
@PostMapping("/save")
public ResponseEntity<String> saveCustomer(@RequestBody @Valid customer c) {
	
	customer op = cservice.SearchByName(c.getCname());
	if (!(op==null)) {
		return new ResponseEntity<String>("Customer is already present", HttpStatus.ALREADY_REPORTED);
	}
	cservice.saveCustomer(c);
	return new ResponseEntity<String>("Successfully added", HttpStatus.CREATED);

}

// Get all customer item
	@GetMapping("/allCustomer")
	public List<customer> getAllFood() {
		List<customer> list = cservice.AllCustomer();
		return list;
	}
	@DeleteMapping("/deletecustomer/{id}")
	public ResponseEntity<String> deleteProductById(@PathVariable("id") int id)
	{
		Optional<customer> op=cservice.Detail(id);
		if(op.isPresent())
		{
			cservice.Delete(id);
			return new ResponseEntity<String>("DELETE-SUCCESSFULLY",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Not Found",HttpStatus.NOT_FOUND);
	}
	@PutMapping("/updateCustomer/{id}")
	public ResponseEntity<Object> updateCustomerById(@PathVariable("id") int id, @RequestBody @Valid customer f)
	{
		Optional<customer> op= cservice.Detail(id);
		if(op.isPresent())
		{
			customer c=op.get();
			c.setCname(f.getCname());
			c.setEmail(f.getEmail());
			Optional<customer> fo=cservice.saveCustomer(c);
			return new ResponseEntity<Object>(fo.get(),HttpStatus.OK);
			
		}
		else
			return new ResponseEntity<Object>("NOT FOUND",HttpStatus.NOT_FOUND);
	}
	@DeleteMapping("/deleteallcustomer")
	public ResponseEntity<String> DeleteAllCustomers()
	{
		cservice.DeleteAll();
		return new ResponseEntity<String>("DELETED ALL Customers",HttpStatus.GONE);
	}
}
