package com.capg.main.advice;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class MyAdviceForException {
	public MyAdviceForException() {
		System.out.println("advice object is created");
	}
	
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleInvalidArgument(MethodArgumentNotValidException ae) {
		Map<String, String> map = new LinkedHashMap<>();
		ae.getBindingResult().getFieldErrors().forEach(error -> {
			map.put(error.getField(), error.getDefaultMessage());
		});
		return map;
	}
	
	@ResponseStatus(value=HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(ConstraintViolationException.class)
	public Map<String,String> handleInvalidArguments(ConstraintViolationException ce)
	{
		Map<String,String> map=new LinkedHashMap<>();
		for(ConstraintViolation cerror:ce.getConstraintViolations())
		{
			map.put(cerror.getPropertyPath().toString(), cerror.getMessage());
		}
		return map;
	}
}