package com.capg.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.capg.main.pojo.food;
import com.capg.main.pojo.orders;
@Repository
public interface OrdersRepository extends CrudRepository<orders,Integer> {
	@Query("select o from orders o where o.odate=:date")
	public List<orders> findAllByDate(@Param("date") String date);
}