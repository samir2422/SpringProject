package com.capg.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.capg.main.pojo.food;
import com.capg.main.repository.FoodRepository;

	@Service
	public class FoodService {
		@Autowired
		private FoodRepository repo;

		public Optional<food> saveFood(food fod) {
			repo.save(fod);
			return repo.findById(fod.getId());
		}
		
		public Optional<food> Detail(int itemid) {
			return repo.findById(itemid);
		}
		
		public List<food> AllFood(){
			List<food> list = new ArrayList();
			repo.findAll().forEach(list::add);
			return list;
		}
		public void Delete(int itemid)
		{
			repo.deleteById(itemid);
		}
		public void DeleteAll()
		{
			repo.deleteAll();
		}
		public food SearchByName(String name)
		{
			food f= repo.SearchByName(name);
			if(f==null)
				return null;
			return f;
		}
		public List<food> SearchInRange(int low,int high)
		{
			List<food> list = new ArrayList();
			repo.SearchInRange(low, high).forEach(list::add);
			return list;
		}
		public List<food> SortByPrice()
		{
			List<food> list = new ArrayList();
			repo.SortByPrice().forEach(list::add);
			return list;
		}
}